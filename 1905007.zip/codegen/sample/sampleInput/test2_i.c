int main(){
 
	int i,j,k;
	
	i = 3;
	j = 8;
	k = 6;
	
	
	if(i==3){
		println(j);
	}
	
	if(j<8){
		println(i);
	}
	else{
		println(k);
	}
	
	if(k != 6){
		println(k);
	}
	else if(j > 8){
		println(j);
	}
	else if(i < 5){
		println(i);
	}
	else{
		k = 0;
		println(k);
	}
 
 
	return 0;
}

